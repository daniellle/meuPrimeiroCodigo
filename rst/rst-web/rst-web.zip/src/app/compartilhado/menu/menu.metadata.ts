export interface IMenu {

  path: string;
  title: string;
  icon: string;
  class: string;

}
