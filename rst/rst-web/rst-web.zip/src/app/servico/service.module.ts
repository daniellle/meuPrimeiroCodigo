import {NgModule} from '@angular/core';
import {AutenticacaoService} from './autenticacao.service';

@NgModule({
  imports: [],
  providers: [
    AutenticacaoService,
  ],
})
export class ServiceAppModule {
}
