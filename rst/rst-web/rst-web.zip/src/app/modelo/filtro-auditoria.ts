export class AuditoriaFilter {
    dataInicial: string;
    dataFinal: string;
    usuario: string;
    funcionalidade: string;
    tipoOperacaoAuditoria: string;
}
