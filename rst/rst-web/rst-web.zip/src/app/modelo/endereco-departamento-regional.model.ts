import { Endereco } from 'app/modelo/endereco.model';

export class EnderecoDepartamentoRegional {
    endereco: Endereco;

    constructor() {
        this.endereco = new Endereco();
    }
}
