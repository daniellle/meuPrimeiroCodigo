import { Perfil } from './perfil.model';
import { Sistema } from './sistema.model';
export class PerfilSistema{
    perfil: Perfil = new Perfil();
    sistemas: Array<any> = [];
}