
export class IndicadorQuestionario {
    id: number;
    descricao: string;
    orientacao: string;
    incentivo: string;
}
