import { Email } from 'app/modelo/email.model';

export class EmailUnidAtendTrabalhador {
    id: number;
    email: Email;
}
