export class ProximaDoseDTO{
    id: number;
    nome: String;
    dataVacinacao: Date;

}
