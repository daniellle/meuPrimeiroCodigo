
export class Cnae {
    id: number ;
    versao: string;
    codigo: string;
    descricao: string ;
    numeroGrauDeRisco: string;
    dataCriacao: Date;
    dataAlteracao: Date;
    dataExclusao: Date;
}
