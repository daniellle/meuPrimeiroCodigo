export class FiltroCnae {
    versao: string;
    codigo: string;
    descricao: string;
    ids: string[];

    constructor () {
        this.versao = '';
        this.codigo = '';
        this.descricao = '';
    }
}
