export class SolicitacaoEmail {
    cpf: string;
    nome: string;
    email: string;
    telefone: string;

}