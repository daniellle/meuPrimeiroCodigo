export class CboFilter {

    codigo: string;
    descricao: string;
    idCbos: string;
    idEmpresa: number;

}
