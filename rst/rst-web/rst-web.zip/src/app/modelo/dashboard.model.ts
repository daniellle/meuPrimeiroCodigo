export class Dashboard {

}
