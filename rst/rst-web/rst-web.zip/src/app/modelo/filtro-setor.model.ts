export class FiltroSetor {

    sigla: string;
    descricao: string;
    idSetor: number[];
    idEmpresa: number;

    constructor() {
        this.idSetor = new Array<number>();
    }
}
