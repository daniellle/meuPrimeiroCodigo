export enum EnumTipoResposta {
    M  = 'Múltipla',
    S = 'Simples',
}
