import { enumFiltro } from './enum/enum.filtroVacina.model';

export class FiltroVacina {

    nome = '';
    periodo: '';
    codPeriodo: enumFiltro;

}
