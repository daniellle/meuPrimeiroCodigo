
export class Linha {

        id: number;
        descricao: string;
        dataCriacao: Date;
        dataAlteracao: Date;
        dataExclusao: Date;

        constructor() {}
}
