export class FiltroEmpresa {
id: number;
cnpj: string;
razaoSocial: string;
nomeFantasia: string;
unidadeObra: number;
situacao = '';
perfil: string;
porte: '';
idEstado: '';
cnae: string;

idUnidadeObra: number;
}
