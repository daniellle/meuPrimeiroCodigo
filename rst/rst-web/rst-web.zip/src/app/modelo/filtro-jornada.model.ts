export class JornadaFilter {

    turno: string;
    qtdHoras: string;
    idJornadas: string;
    idEmpresa: number;

    constructor() {

     }

}
