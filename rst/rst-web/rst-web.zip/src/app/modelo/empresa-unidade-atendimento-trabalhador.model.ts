export class EmpresaUnidadeAtendimentoTrabalhador {

}
