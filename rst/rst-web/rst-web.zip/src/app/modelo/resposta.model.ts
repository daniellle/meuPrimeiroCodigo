export class Resposta {
    id: number;
    descricao: string;

    constructor() {
    }
}
