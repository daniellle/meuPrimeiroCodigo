import { RespostaQuestionario } from './resposta-questionario.model';
import { QuestionarioTrabalhador } from './questionario-trabalhador';
export class RespostaQuestionarioTabalhador {
    id: number;
    questionarioTrabalhador: QuestionarioTrabalhador;
    respostaQuestionario: RespostaQuestionario;

}
