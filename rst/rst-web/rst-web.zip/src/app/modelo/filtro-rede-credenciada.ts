
export class FiltroRedeCredenciada {
    cnpj: string;
    razaoSocial: string;
    segmento = '';
    situacao = '';
}
