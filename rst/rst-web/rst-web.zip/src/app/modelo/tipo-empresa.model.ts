export class TipoEmpresa {
    id: number;
    descricao: string;
}
