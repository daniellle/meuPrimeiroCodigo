export class TipoCurso {
    id = '';
    descricao: string;
}