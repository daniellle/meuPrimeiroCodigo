
export class ClassificacaoPontuacao {

    id: number;
    descricao: string;
    mensagem: string;
    recomendacao: string;
    valorMaximo: number;
    valorMinimo: number;

    constructor() {
    }
}
