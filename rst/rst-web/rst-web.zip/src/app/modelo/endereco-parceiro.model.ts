import { Endereco } from './endereco.model';
export class EnderecoParceiro {
    id: number;
    endereco: Endereco;
}
