import { TipoQuestionario } from './tipo-questionario.model';
export class QuestionarioFilter {
    nome: string;
    situacao = '';
    versao = '';
    tipo = '';
}
