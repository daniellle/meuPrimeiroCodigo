import { Pais } from 'app/modelo/pais.model';

export class Estado {
    id: number;
    descricao: string;
    pais: Pais;
    siglaUF: string;
}
