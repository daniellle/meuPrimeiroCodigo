export class ProdutoServicoDTO {
    nome: string;
}
