export class RamoEmpresa {
    id: number;
    descricao: string;
}
