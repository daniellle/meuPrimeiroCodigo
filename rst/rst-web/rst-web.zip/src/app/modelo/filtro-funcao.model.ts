export class FiltroFuncao {
    codigo: string;
    descricao: string;
    idFuncao: number[];
    idEmpresa: number;

    constructor() {
        this.idFuncao = new Array<number>();
    }
}
