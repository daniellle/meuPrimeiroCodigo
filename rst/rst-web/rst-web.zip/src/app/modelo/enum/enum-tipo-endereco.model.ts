export enum TipoEndereco {
    C = 'Comercial',
    F = 'Financeiro',
    P = 'Principal',
}
