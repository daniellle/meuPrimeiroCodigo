export enum StatusQuestionario {
    E = 'Em Edição',
    D = 'Desativado',
    P = 'Publicado',
}
