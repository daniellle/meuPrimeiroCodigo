export enum TipoOperacaoAuditoria {
    TDS = 'Todos',
    A = 'Alteração',
    C = 'Consulta',
    E = 'Exclusão',
    I = 'Inclusão',
}
