export enum Situacao {
    A = 'Ativo',
    I = 'Inativo',
}
