export enum enumFiltro{
    UMES = "Ultimo Mes",
    UTRI = "Ultimo Trimestre", 
    USEM = "Ultimo Semestre",
    UANO = "Ultimo ano",
    U5AN = "Ultimos cinco anos",
    U10A = "Ultimos dez anos" 

}