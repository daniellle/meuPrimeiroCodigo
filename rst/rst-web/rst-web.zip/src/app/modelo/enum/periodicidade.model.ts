export class Periodicidade {
    id: number;
    descricao: string;
}
