export enum TipoSanguineo {
    AP = 'A+',
    AN = 'A-',
    ABP = 'AB+',
    AB = 'AB',
    BP = 'B+',
    BN = 'B-',
    OP = 'O+',
    ON = 'O-',
}
