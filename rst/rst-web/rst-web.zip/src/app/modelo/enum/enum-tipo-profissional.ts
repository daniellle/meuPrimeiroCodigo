export enum TipoProfissional {
    ARQURB = 'Arquiteto e Urbanista - Especialista em Segurança do Trabalho',
    AUXENF = 'Auxiliar de Enfermagem',
    ENF = 'Enfermeiro(a)',
    ENGSEG = 'Engenheiro(a) de Segurança',
    ENG = 'Engenheiro(a) de Segurança do Trabalho',
    ME = 'Médico(a)',
    FO = 'Fonoaudiólogo(a)',
    TECSEG = 'Técnico(a) de Segurança,',
    TECENF = 'Técnico de Enfermagem',
    TECSEGTRAB = 'Técnico(a) de Segurança do Trabalho',
    TECNOSEGTRAB = 'Tecnólogo de Segurança do Trabalho',
}
