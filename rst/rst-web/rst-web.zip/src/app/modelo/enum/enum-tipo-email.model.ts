export enum TipoEmail {
   P =  'Pessoal',
   T  = 'Trabalho',
}
