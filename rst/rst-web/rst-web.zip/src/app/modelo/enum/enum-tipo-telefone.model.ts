export enum TipoTelefone {
   CE = 'Celular',
   CO  = 'Comercial',
   F =  'Fax',
   R =  'Residencial',
   W =  'Whatsapp',
}
