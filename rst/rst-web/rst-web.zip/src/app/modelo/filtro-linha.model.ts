export class FiltroLinha {
    aplicarDadosFilter = true;

    constructor() {
    }
}
