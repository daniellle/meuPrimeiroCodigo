export class SpecialDates{
    Date: Date;
    Class: string;
    Tooltip: string;
}