export class PorteEmpresa {
    id: number;
    descricao: string;
}
