export class FiltroSegmento {
    codigo: string;
    descricao: string;

    constructor() {
    }
}
