export class MensagemErro {
    erro: string;
}
