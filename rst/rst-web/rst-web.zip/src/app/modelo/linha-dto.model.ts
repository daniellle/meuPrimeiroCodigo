import { ProdutoServicoDTO } from './produto-servico-dto.model';

export class LinhaDTO {
    descricao: string;
    produtosServicos: ProdutoServicoDTO[];
}
