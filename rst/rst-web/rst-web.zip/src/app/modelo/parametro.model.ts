export class Parametro {
    nome: string;
    valor: string;
}
