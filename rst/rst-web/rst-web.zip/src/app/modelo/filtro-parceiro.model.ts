export class FiltroParceiro {

    cpfCnpj: string;
    razaoSocialNome: string;
    especialidade = '';
    situacao = '';

    }
