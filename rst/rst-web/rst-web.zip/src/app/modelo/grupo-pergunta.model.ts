
export class GrupoPergunta {

    id: number;
    descricao: string;
    dataCriacao: Date;
    dataAlteracao: Date;
    dataExclusao: Date;

    constructor() {
    }
}
