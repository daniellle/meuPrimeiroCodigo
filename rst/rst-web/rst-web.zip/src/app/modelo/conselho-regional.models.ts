
export class ConselhoRegional {
    id: number;
    nome: string;
    sigla: string;
}
