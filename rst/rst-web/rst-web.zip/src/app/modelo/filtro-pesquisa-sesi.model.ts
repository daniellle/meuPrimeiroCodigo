export class FiltroPesquisaSesi {
    idUnidadeSesi: string;
    idEstado: string;
    idMunicipio: string;
    bairro: string;
    idLinha: number[];
    idProduto: number[];
}