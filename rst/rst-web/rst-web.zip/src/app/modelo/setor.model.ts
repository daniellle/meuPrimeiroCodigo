export class Setor {

    id: number;
    sigla: string;
    descricao: string;
    dataCriacao: Date;
    dataAlteracao: Date;
    dataExclusao: Date;

    constructor() {
    }
 }
