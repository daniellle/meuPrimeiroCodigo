export class Funcao {

    id: number;
    codigo: string;
    descricao: string;
    dataCriacao: Date;
    dataAlteracao: Date;
    dataExclusao: Date;

    constructor() {
    }
 }
