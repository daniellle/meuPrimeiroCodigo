export class Pais {
    id: number;
    descricao: string;
}
