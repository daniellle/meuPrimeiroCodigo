import { DvText } from "@ezvida/adl-core";

export class Imunizacao{
    nome: string;
    data: Date;

    constructor(){
    }
}