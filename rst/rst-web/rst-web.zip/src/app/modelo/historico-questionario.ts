export class HistoricoQuestionario {
    dataQuestionario: string;
    nome: string;
    pontuacao: number;
    id: number;
}