export class FiltroEndereco {
    idEstado: string;
    idMunicipio: string;
    bairro: string;
}