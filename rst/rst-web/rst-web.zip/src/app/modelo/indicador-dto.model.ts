export class IndicadorDTO {

    descricao: string;
    orientacao: string;
    aprovado: boolean;
    incentivo: string;
}
