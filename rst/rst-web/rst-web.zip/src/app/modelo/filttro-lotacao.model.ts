export class FiltroLotacao {

    idEmpresa: number;
    idUnidadeObra: number;
    idSetor: number;
    idCargo: number;
    idFuncao: number;
    idJornada: number;

    constructor() {}
}
