export class TipoQuestionario {
    id: number;
    descricao: string;
}
