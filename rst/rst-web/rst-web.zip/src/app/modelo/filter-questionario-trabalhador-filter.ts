export class QuestionarioTrabalhadorFilter {
    id: number;
    nome: string;
}
