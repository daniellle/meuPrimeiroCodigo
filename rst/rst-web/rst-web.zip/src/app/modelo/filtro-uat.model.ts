export class FiltroUat {
    situacao = '';
    idDepRegional: number;
    cnpj: string;
    razaoSocial: string;
    cpfUsuarioAssociado: string;
}
