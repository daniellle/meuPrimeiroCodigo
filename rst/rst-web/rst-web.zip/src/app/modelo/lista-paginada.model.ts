export class ListaPaginada<T> {
    quantidade: number;
    list: T[];
}
