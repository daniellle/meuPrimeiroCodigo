export class RespostaDTO {
    id: number;
    descricao: string;
    ordenacao: number;
    tipoResposta: string;
    selecionado: string;
}
