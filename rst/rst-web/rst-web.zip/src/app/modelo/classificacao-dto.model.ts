export class ClassificacaoDTO {

    classificacao: String;
    url: String;
    mensagem: String;
}
