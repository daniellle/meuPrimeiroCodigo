import { Email } from 'app/modelo/email.model';

export class EmailDepartamentoRegional {
    email: Email;

    constructor() {
        this.email = new Email();
    }
}
