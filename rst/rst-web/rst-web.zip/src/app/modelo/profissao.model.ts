export class Profissao {
    id: number;
    descricao: string;
}
