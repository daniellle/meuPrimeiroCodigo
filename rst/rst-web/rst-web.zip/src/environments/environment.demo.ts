export const environment = {
    production: true,
    envName: 'demo',
    api_private: 'https://demo-www.sesivivamais.com.br/rst/api/private',
    api_public: 'https://demo-www.sesivivamais.com.br/rst/api/public',
    url_portal: 'https://demo-www.sesivivamais.com.br',
    path_raiz_cadastro: 'cadastro',
    path_raiz: '',
    baseHref: '/rst',
    exibirMenu: false,
    exibirWS: false,
    isProduction: false,
};
