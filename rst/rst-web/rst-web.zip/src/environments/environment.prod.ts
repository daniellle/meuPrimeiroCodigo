export const environment = {
    production: true,
    api_private: 'https://www.sesivivamais.com.br/rst/api/private',
    api_public: 'https://www.sesivivamais.com.br/rst/api/public',
    imunizacao_api: 'http://localhost:8081',
    url_portal: 'https://www.sesivivamais.com.br',
    path_raiz_cadastro: 'cadastro',
    path_raiz: '',
    baseHref: '/rst',
    exibirMenu: false,
    exibirWS: false,
    isProduction: true,
};
