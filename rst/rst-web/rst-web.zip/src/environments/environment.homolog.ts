export const environment = {
    production: true,
    envName: 'homolog',
    api_private: 'https://homolog-www.sesivivamais.com.br/rst/api/private',
    api_public: 'https://homolog-www.sesivivamais.com.br/rst/api/public',
    imunizacao_api: 'http://localhost:8081',
    url_portal: 'https://homolog-www.sesivivamais.com.br',
    path_raiz_cadastro: 'cadastro',
    path_raiz: '',
    baseHref: '/rst',
    exibirMenu: false,
    exibirWS: false,
    isProduction: false,
};
