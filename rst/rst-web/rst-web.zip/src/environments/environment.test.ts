export const environment = {
    production: false,
    envName: 'test',
    api_private: 'https://teste-www.sesivivamais.com.br/rst/api/private',
    api_public: 'https://teste-www.sesivivamais.com.br/rst/api/public',
    imunizacao_api: 'http://localhost:8081',
    url_portal: 'https://teste-www.sesivivamais.com.br',
    path_raiz_cadastro: 'cadastro',
    path_raiz: '',
    baseHref: '/rst',
    exibirMenu: false,
    exibirWS: false,
    isProduction: false,
};
