export enum Raca {
    A = 'Amarela',
    B = 'Branca',
    I = 'Indígena',
    PA = 'Parda',
    PR = 'Preta',
    SD = 'Sem Declaração',
}
