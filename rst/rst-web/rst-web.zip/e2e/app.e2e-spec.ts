describe('Inicio de testes App', () => {

  it('Executou testes', function() {
    expect(true).toBe(true);
 }); 
});
